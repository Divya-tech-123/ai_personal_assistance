// ============================================================
//  ARIA Frontend — app.js
//  Communicates with Node.js backend at localhost:3000
// ============================================================

const API = 'http://localhost:3000/api';
let taskFilter  = 'all';
let recognition = null;
let allTasks    = [];

// ══════════════════════════════════════════════════════════════
//  SERVER HEALTH CHECK
// ══════════════════════════════════════════════════════════════
async function checkServer() {
  try {
    const res = await fetch(`${API}/health`);
    if (res.ok) {
      document.getElementById('serverDot').className    = 'dot online';
      document.getElementById('serverStatus').textContent = 'Backend Online';
      document.getElementById('chatStatus').textContent   = '● Connected to backend';
      document.getElementById('chatStatus').style.color   = 'var(--green)';
    } else throw new Error();
  } catch {
    document.getElementById('serverDot').className    = 'dot offline';
    document.getElementById('serverStatus').textContent = 'Backend Offline';
    document.getElementById('chatStatus').textContent   = '● Backend not running';
    document.getElementById('chatStatus').style.color   = 'var(--red)';
  }
}

// Check server every 10 seconds
checkServer();
setInterval(checkServer, 10000);

// ══════════════════════════════════════════════════════════════
//  NAVIGATION
// ══════════════════════════════════════════════════════════════
function showPage(name) {
  document.querySelectorAll('.page').forEach(p => { p.classList.remove('active'); p.style.display = 'none'; });
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));

  const page = document.getElementById(name);
  const tab  = document.getElementById('tab-' + name);

  if (name === 'chat') { page.style.display = 'grid'; page.classList.add('active'); }
  else                 { page.style.display = 'flex';  page.classList.add('active'); }

  if (tab) tab.classList.add('active');

  if (name === 'tasks')     loadTasks();
  if (name === 'dashboard') loadDashboard();
}

// ══════════════════════════════════════════════════════════════
//  CHAT
// ══════════════════════════════════════════════════════════════
function sendChip(el) { document.getElementById('msgInput').value = el.textContent; sendMessage(); }
function handleKey(e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } }
function autoResize(el) { el.style.height = 'auto'; el.style.height = Math.min(el.scrollHeight, 120) + 'px'; }

async function sendMessage() {
  const input = document.getElementById('msgInput');
  const text  = input.value.trim();
  if (!text) return;

  const empty = document.getElementById('emptyState');
  if (empty) empty.style.display = 'none';

  addBubble('user', text);
  input.value = ''; input.style.height = 'auto';
  document.getElementById('sendBtn').disabled = true;

  const typingId = 'typing-' + Date.now();
  addTyping(typingId);

  try {
    const res = await fetch(`${API}/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: text }),
    });

    removeTyping(typingId);

    if (!res.ok) throw new Error('Backend returned error ' + res.status);

    const data = await res.json();
    addBubble('assistant', data.reply);
    updateHistory(text);

  } catch (err) {
    removeTyping(typingId);
    addBubble('assistant', `⚠️ **Cannot reach backend.**\n\nMake sure the Node.js server is running:\n\`\`\`\ncd backend\nnpm install\nnode server.js\n\`\`\`\n\nThen refresh the page.`);
  }

  document.getElementById('sendBtn').disabled = false;
}

function addBubble(role, content) {
  const msgs = document.getElementById('messages');
  const now  = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const row  = document.createElement('div'); row.className = `msg-row ${role}`;
  const av   = document.createElement('div'); av.className  = `msg-av ${role === 'assistant' ? 'ai' : 'user'}`;
  av.textContent = role === 'assistant' ? 'AI' : 'U';
  const wrap   = document.createElement('div');
  const bubble = document.createElement('div'); bubble.className = `msg-bubble ${role === 'assistant' ? 'ai' : 'user'}`;
  if (role === 'assistant') bubble.innerHTML = parseMarkdown(content);
  else bubble.textContent = content;
  const time = document.createElement('div'); time.className = 'msg-time'; time.textContent = now;
  wrap.appendChild(bubble); wrap.appendChild(time);
  row.appendChild(av); row.appendChild(wrap);
  msgs.appendChild(row);
  msgs.scrollTop = msgs.scrollHeight;
}

function addTyping(id) {
  const msgs = document.getElementById('messages');
  const row  = document.createElement('div'); row.className = 'msg-row'; row.id = id;
  const av   = document.createElement('div'); av.className  = 'msg-av ai'; av.textContent = 'AI';
  const b    = document.createElement('div'); b.className   = 'msg-bubble ai';
  b.innerHTML = '<div class="typing-dots"><span></span><span></span><span></span></div>';
  row.appendChild(av); row.appendChild(b); msgs.appendChild(row);
  msgs.scrollTop = msgs.scrollHeight;
}

function removeTyping(id) { const el = document.getElementById(id); if (el) el.remove(); }

function parseMarkdown(t) {
  return t
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/```([\s\S]*?)```/g,'<pre><code>$1</code></pre>')
    .replace(/`([^`]+)`/g,'<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>')
    .replace(/\*([^*]+)\*/g,'<em>$1</em>')
    .replace(/^> (.+)$/gm,'<blockquote>$1</blockquote>')
    .replace(/^### (.+)$/gm,'<h3>$1</h3>').replace(/^## (.+)$/gm,'<h3>$1</h3>')
    .replace(/^[-*] (.+)$/gm,'<li>$1</li>')
    .replace(/(<li[\s\S]*?<\/li>)/g,'<ul>$1</ul>')
    .replace(/\n\n/g,'<br><br>').replace(/\n/g,'<br>');
}

function clearChat() {
  document.getElementById('messages').innerHTML = `
    <div class="empty-state" id="emptyState">
      <div class="empty-icon">✦</div>
      <div class="empty-text">How can I help you today?</div>
      <div class="empty-sub">Powered by a real Node.js backend</div>
      <div class="chips">
        <button class="chip" onclick="sendChip(this)">What can you do?</button>
        <button class="chip" onclick="sendChip(this)">Give me productivity tips</button>
        <button class="chip" onclick="sendChip(this)">Help me plan my day</button>
        <button class="chip" onclick="sendChip(this)">Show my tasks</button>
        <button class="chip" onclick="sendChip(this)">Tell me a joke</button>
        <button class="chip" onclick="sendChip(this)">What time is it?</button>
      </div>
    </div>`;
  showToast('Chat cleared');
}

function newChat() { clearChat(); }

function updateHistory(text) {
  const list = document.getElementById('historyList');
  const item = document.createElement('div'); item.className = 'hist-item active';
  item.textContent = text.slice(0, 32) + (text.length > 32 ? '...' : '');
  list.querySelectorAll('.hist-item').forEach(i => i.classList.remove('active'));
  list.prepend(item);
}

// ══════════════════════════════════════════════════════════════
//  VOICE
// ══════════════════════════════════════════════════════════════
function startVoice() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { showToast('⚠ Speech recognition not supported'); return; }
  recognition = new SR(); recognition.lang = 'en-US'; recognition.interimResults = true;
  document.getElementById('voiceOverlay').classList.add('show');
  document.getElementById('voiceTranscript').textContent = 'Speak now...';
  document.getElementById('voiceBtn').classList.add('recording');
  recognition.onresult = (e) => {
    const t = Array.from(e.results).map(r => r[0].transcript).join('');
    document.getElementById('voiceTranscript').textContent = '"' + t + '"';
    if (e.results[e.results.length - 1].isFinal) {
      document.getElementById('msgInput').value = t;
      closeVoiceModal();
    }
  };
  recognition.onerror = () => closeVoiceModal();
  recognition.onend   = () => closeVoiceModal();
  recognition.start();
}

function closeVoiceModal() {
  document.getElementById('voiceOverlay').classList.remove('show');
  document.getElementById('voiceBtn').classList.remove('recording');
  if (recognition) { recognition.abort(); recognition = null; }
}

function closeVoice(e) { if (e.target === e.currentTarget) closeVoiceModal(); }

// ══════════════════════════════════════════════════════════════
//  TASKS
// ══════════════════════════════════════════════════════════════
async function loadTasks() {
  try {
    const res = await fetch(`${API}/tasks`);
    allTasks  = await res.json();
    renderTasks();
  } catch {
    document.getElementById('taskList').innerHTML = '<div class="no-tasks">⚠ Could not load tasks — is the backend running?</div>';
  }
}

async function addTask() {
  const title = document.getElementById('taskTitle').value.trim();
  if (!title) { showToast('⚠ Please enter a task title'); return; }

  try {
    const res = await fetch(`${API}/tasks`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title,
        priority: document.getElementById('taskPriority').value,
        category: document.getElementById('taskCategory').value,
      }),
    });
    const task = await res.json();
    allTasks.unshift(task);
    document.getElementById('taskTitle').value = '';
    renderTasks();
    showToast('✅ Task added!');
  } catch { showToast('⚠ Failed to add task'); }
}

async function toggleTask(id) {
  try {
    const res  = await fetch(`${API}/tasks/${id}/toggle`, { method: 'PATCH' });
    const task = await res.json();
    const idx  = allTasks.findIndex(t => t.id === id);
    if (idx !== -1) allTasks[idx] = task;
    renderTasks();
  } catch { showToast('⚠ Failed to update task'); }
}

async function deleteTask(id) {
  try {
    await fetch(`${API}/tasks/${id}`, { method: 'DELETE' });
    allTasks = allTasks.filter(t => t.id !== id);
    renderTasks();
    showToast('🗑 Task deleted');
  } catch { showToast('⚠ Failed to delete task'); }
}

function setFilter(f, btn) {
  taskFilter = f;
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderTasks();
}

function renderTasks() {
  const total   = allTasks.length;
  const done    = allTasks.filter(t => t.done).length;
  const pending = total - done;
  const high    = allTasks.filter(t => t.priority === 'high' && !t.done).length;

  ['Total','Done','Pending','High'].forEach((k, i) => {
    const el = document.getElementById('stat' + k);
    if (el) el.textContent = [total, done, pending, high][i];
  });

  const badge = document.getElementById('pendingBadge');
  if (badge) badge.textContent = pending + ' pending';

  const date = document.getElementById('taskDate');
  if (date) date.textContent = new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

  let filtered = allTasks;
  if (taskFilter === 'pending') filtered = allTasks.filter(t => !t.done);
  if (taskFilter === 'done')    filtered = allTasks.filter(t => t.done);
  if (taskFilter === 'high')    filtered = allTasks.filter(t => t.priority === 'high');

  const list = document.getElementById('taskList');
  if (!list) return;

  if (filtered.length === 0) {
    list.innerHTML = '<div class="no-tasks">🎉 No tasks here — all caught up!</div>';
    return;
  }

  list.innerHTML = filtered.map(t => `
    <div class="task-item">
      <button class="task-cb ${t.done ? 'done' : ''}" onclick="toggleTask(${t.id})">${t.done ? '✓' : ''}</button>
      <div class="task-body">
        <div class="task-ttl ${t.done ? 'done' : ''}">${escHtml(t.title)}</div>
        <div class="task-meta">
          <span class="tag ${t.priority}">${t.priority.charAt(0).toUpperCase() + t.priority.slice(1)}</span>
          <span class="tag cat">${escHtml(t.category)}</span>
        </div>
      </div>
      <button class="task-del" onclick="deleteTask(${t.id})">✕</button>
    </div>`).join('');
}

// ══════════════════════════════════════════════════════════════
//  DASHBOARD
// ══════════════════════════════════════════════════════════════
async function loadDashboard() {
  const date = document.getElementById('dashDate');
  if (date) date.textContent = new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

  try {
    // Load stats
    const statsRes = await fetch(`${API}/stats`);
    const stats    = await statsRes.json();
    ['Total','Done','Pending','High'].forEach(k => {
      const el = document.getElementById('dStat' + k);
      if (el) el.textContent = stats[k.toLowerCase()] ?? 0;
    });

    // Load activity
    const actRes  = await fetch(`${API}/activity`);
    const actData = await actRes.json();
    const feed    = document.getElementById('activityFeed');
    if (feed) {
      feed.innerHTML = actData.slice(0, 8).map(a => `
        <div class="activity-item">
          <div class="act-icon">${a.icon}</div>
          <div>
            <div class="act-text">${escHtml(a.text)}</div>
            <div class="act-time">${formatTime(a.time)}</div>
          </div>
        </div>`).join('') || '<div style="color:var(--ink4);text-align:center;padding:1rem;font-size:.8rem">No activity yet</div>';
    }

    // Load reminders
    const remRes  = await fetch(`${API}/reminders`);
    const remData = await remRes.json();
    const remList = document.getElementById('reminderList');
    if (remList) {
      remList.innerHTML = remData.map(r => `
        <div class="reminder-row">
          <div class="rem-dot" style="background:${r.color}"></div>
          <div class="rem-text">${escHtml(r.text)}</div>
          <div class="rem-time">${escHtml(r.time)}</div>
        </div>`).join('') || '<div style="color:var(--ink4);text-align:center;padding:1rem;font-size:.8rem">No reminders yet</div>';
    }

  } catch {
    document.getElementById('activityFeed').innerHTML  = '<div style="color:var(--red);font-size:.8rem;padding:1rem">⚠ Backend not connected</div>';
    document.getElementById('reminderList').innerHTML  = '<div style="color:var(--red);font-size:.8rem;padding:1rem">⚠ Backend not connected</div>';
  }
}

async function addReminder() {
  const text = prompt('Reminder text:'); if (!text) return;
  const time = prompt('Time (e.g. 3:00 PM):'); if (!time) return;
  try {
    await fetch(`${API}/reminders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, time }),
    });
    loadDashboard();
    showToast('⏰ Reminder added!');
  } catch { showToast('⚠ Failed to add reminder'); }
}

// ══════════════════════════════════════════════════════════════
//  UTILITIES
// ══════════════════════════════════════════════════════════════
function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function formatTime(isoString) {
  try {
    const diff = Date.now() - new Date(isoString).getTime();
    if (diff < 60000)    return 'just now';
    if (diff < 3600000)  return Math.floor(diff / 60000) + 'm ago';
    if (diff < 86400000) return Math.floor(diff / 3600000) + 'h ago';
    return new Date(isoString).toLocaleDateString();
  } catch { return isoString; }
}

function showToast(msg) {
  const t = document.createElement('div'); t.className = 'toast'; t.textContent = msg;
  document.body.appendChild(t); setTimeout(() => t.remove(), 2800);
}
