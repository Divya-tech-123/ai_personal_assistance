# ARIA — Full Stack Personal Assistant
### Node.js Backend + HTML/CSS/JS Frontend

---

## Project Structure

```
aria-fullstack/
│
├── frontend/                 ← HTML/CSS/JS (User Interface)
│   ├── index.html            ← Main page
│   ├── css/
│   │   └── style.css         ← All styles
│   └── js/
│       └── app.js            ← All frontend logic + API calls
│
├── backend/                  ← Node.js + Express (Server)
│   ├── server.js             ← Main server + AI brain + REST API
│   ├── package.json          ← Dependencies
│   └── data/                 ← Auto-created JSON storage
│       ├── tasks.json
│       ├── reminders.json
│       └── activity.json
│
├── aria-fullstack.code-workspace
└── README.md
```

---

## How to Run in VS Code

### Step 1 — Open Project
```
File → Open Folder → select "aria-fullstack" folder
```

### Step 2 — Start Backend
Open the **Terminal** in VS Code (`Ctrl + `` ` ``):
```bash
cd backend
npm install
node server.js
```
✅ You'll see:
```
✅ Server running at: http://localhost:3000
```

### Step 3 — Open Frontend
Open a **second terminal** tab (click the + icon in terminal):
```bash
cd frontend
```
Then right-click `frontend/index.html` → **"Open with Live Server"**

OR just open: **http://localhost:3000** in your browser (backend serves the frontend too!)

---

## API Endpoints

| Method | Endpoint             | Description           |
|--------|----------------------|-----------------------|
| GET    | `/api/health`        | Server health check   |
| POST   | `/api/chat`          | Chat with ARIA        |
| GET    | `/api/tasks`         | Get all tasks         |
| POST   | `/api/tasks`         | Create a task         |
| PATCH  | `/api/tasks/:id/toggle` | Toggle complete    |
| DELETE | `/api/tasks/:id`     | Delete a task         |
| GET    | `/api/reminders`     | Get all reminders     |
| POST   | `/api/reminders`     | Create a reminder     |
| GET    | `/api/activity`      | Get activity feed     |
| GET    | `/api/stats`         | Get dashboard stats   |

---

## No API Key Needed
ARIA's brain is built into `backend/server.js` — it responds to:
- Greetings & farewells
- Productivity tips & planning
- Task summaries (live from backend)
- Jokes & motivation
- Math calculations
- Time & date
- And much more!

---

## Tech Stack
| Layer    | Technology        |
|----------|-------------------|
| Backend  | Node.js + Express |
| Storage  | JSON files        |
| Frontend | HTML + CSS + JS   |
| API      | REST (fetch)      |
| Port     | 3000              |
