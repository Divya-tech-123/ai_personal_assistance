// ============================================================
//  ARIA Backend — Node.js + Express
//  No external API needed — built-in AI brain
//  Run: node server.js
// ============================================================

const express = require('express');
const cors    = require('cors');
const path    = require('path');
const fs      = require('fs');

const app  = express();
const PORT = 3000;

// ── Middleware ──────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// ── Data Storage (JSON files) ───────────────────────────────
const DATA_DIR      = path.join(__dirname, 'data');
const TASKS_FILE    = path.join(DATA_DIR, 'tasks.json');
const REMINDERS_FILE= path.join(DATA_DIR, 'reminders.json');
const ACTIVITY_FILE = path.join(DATA_DIR, 'activity.json');

// Create data directory if not exists
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);

function readJSON(file, def = []) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch { return def; }
}

function writeJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// Seed default data
if (!fs.existsSync(TASKS_FILE)) {
  writeJSON(TASKS_FILE, [
    { id: 1, title: 'Review project proposal', priority: 'high',   category: 'Work',     done: false, created: Date.now() },
    { id: 2, title: 'Buy groceries',           priority: 'low',    category: 'Shopping', done: true,  created: Date.now() },
    { id: 3, title: 'Read design systems book',priority: 'medium', category: 'Learning', done: false, created: Date.now() },
  ]);
}

if (!fs.existsSync(REMINDERS_FILE)) {
  writeJSON(REMINDERS_FILE, [
    { id: 1, text: 'Morning standup',      time: '09:00 AM', color: '#e8604c' },
    { id: 2, text: 'Review pull requests', time: '02:00 PM', color: '#e9a825' },
    { id: 3, text: 'Evening walk',         time: '06:30 PM', color: '#2a9d8f' },
  ]);
}

if (!fs.existsSync(ACTIVITY_FILE)) {
  writeJSON(ACTIVITY_FILE, [
    { icon: '✦', text: 'ARIA backend started', time: new Date().toISOString() }
  ]);
}

// ── ARIA Brain ──────────────────────────────────────────────
const JOKES = [
  "Why don't scientists trust atoms? Because they make up everything! 😄",
  "Why do programmers prefer dark mode? Because light attracts bugs! 🐛",
  "How do you comfort a JavaScript bug? You console it! 😂",
  "Why was the math book sad? It had too many problems! 📚",
  "I asked ARIA to tell me a joke. She said: this one! 😏",
];

const PRODUCTIVITY_TIPS = [
  "**Pomodoro Technique** 🍅\nWork 25 mins, rest 5 mins. After 4 rounds, take a 15-30 min break. This fights procrastination and maintains focus.",
  "**Top 3 Rule** 🎯\nEvery morning, pick only your 3 most important tasks. Focus on those before anything else.",
  "**Time Blocking** ⏰\nSchedule every task as a calendar event — including breaks. Protect your deep work blocks like meetings.",
  "**Eat the Frog** 🐸\nDo your hardest, most dreaded task first thing in the morning. Everything else feels easy after that.",
  "**2-Minute Rule** ⚡\nIf something takes less than 2 minutes, do it immediately instead of adding it to your list.",
];

const MOTIVATIONAL = [
  "**\"The secret of getting ahead is getting started.\"** — Mark Twain 🌟",
  "**Progress over perfection.** Even 1% improvement every day compounds into massive results over time. 💪",
  "**Done is better than perfect.** Ship it, learn from it, improve it. Keep moving! 🚀",
  "**\"You don't have to be great to start, but you have to start to be great.\"** — Zig Ziglar ✨",
];

function ariaRespond(message) {
  const msg = message.toLowerCase().trim();

  // Greetings
  if (/^(hi|hello|hey|good morning|good evening|good afternoon|howdy|sup)/.test(msg)) {
    const hr = new Date().getHours();
    const greet = hr < 12 ? 'Good morning' : hr < 17 ? 'Good afternoon' : 'Good evening';
    return { reply: `${greet}! 👋 I'm **ARIA**, your personal assistant running on a real Node.js backend!\n\nI can help with productivity tips, task management, daily planning, and more. What can I do for you?` };
  }

  // Farewell
  if (/bye|goodbye|see you|take care|farewell/.test(msg))
    return { reply: "Goodbye! 👋 Have a productive day! Come back anytime. 🌟" };

  // Thanks
  if (/thank|thanks|thank you|thx/.test(msg))
    return { reply: "You're welcome! 😊 Happy to help. Anything else?" };

  // Joke
  if (/joke|funny|laugh|humor/.test(msg))
    return { reply: JOKES[Math.floor(Math.random() * JOKES.length)] };

  // Time / Date
  if (/time|date|today|what day/.test(msg)) {
    const now  = new Date();
    const time = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const date = now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    return { reply: `🕐 **Current time:** ${time}\n📅 **Today is:** ${date}` };
  }

  // Math
  if (/calculate|compute|\d[\s+\-*/]\d/.test(msg)) {
    const expr = msg.replace(/[^0-9+\-*/.() ]/g, '').trim();
    try {
      const result = Function('"use strict"; return (' + expr + ')')();
      if (typeof result === 'number' && isFinite(result))
        return { reply: `🔢 **${expr} = ${result}**` };
    } catch(e) {}
  }

  // Capabilities
  if (/what can you do|help|capabilities|features|how.*work/.test(msg))
    return { reply: "I'm **ARIA** — running on a real **Node.js + Express backend**! 🚀\n\nHere's what I can do:\n\n**💬 Chat**\n- Productivity & focus tips\n- Daily planning help\n- Motivation & quotes\n- Math calculations\n- Tell jokes\n\n**✅ Tasks** *(Tasks tab)*\n- Add, complete, delete tasks\n- Set priorities & categories\n- Filter and search\n\n**📊 Dashboard** *(Dashboard tab)*\n- Live stats from the backend\n- Activity feed\n- Reminders\n\nAll data is stored in **JSON files** on the backend server!" };

  // Tasks
  if (/my task|show task|list task|pending task|how many task/.test(msg)) {
    const tasks   = readJSON(TASKS_FILE);
    const pending = tasks.filter(t => !t.done).length;
    const done    = tasks.filter(t => t.done).length;
    const high    = tasks.filter(t => t.priority === 'high' && !t.done).map(t => `"${t.title}"`).join(', ');
    let reply = `📋 **Your Task Summary** (from backend):\n\n- Total: **${tasks.length}**\n- Completed: **${done}** ✅\n- Pending: **${pending}** ⏳`;
    if (high) reply += `\n- High priority: ${high} 🔴`;
    reply += '\n\nSwitch to the **Tasks tab** to manage them!';
    return { reply };
  }

  // Productivity
  if (/productiv|focus|efficient|work better|tip|improve/.test(msg))
    return { reply: PRODUCTIVITY_TIPS[Math.floor(Math.random() * PRODUCTIVITY_TIPS.length)] };

  // Planning
  if (/plan|schedule|organiz|routine|structure/.test(msg))
    return { reply: "Here's a **daily planning framework** 📅\n\n**🌅 Morning (30 min)**\n- Review task list\n- Pick top 3 priorities\n- Block time in calendar\n\n**🎯 Deep Work Block (2-3 hrs)**\n- Phone on silent\n- One task at a time\n- No email/chat\n\n**🍽️ Lunch Break**\n- Step away from screen\n- Go for a short walk\n\n**📧 Afternoon**\n- Emails and meetings\n- Collaborative tasks\n\n**📝 Evening Wrap-up (15 min)**\n- Mark completed tasks\n- Plan tomorrow's top 3\n\nWant me to add any of these as tasks?" };

  // Motivation
  if (/motivat|inspir|quote|discourag|tired|stuck|give up/.test(msg))
    return { reply: MOTIVATIONAL[Math.floor(Math.random() * MOTIVATIONAL.length)] };

  // Pomodoro
  if (/pomodoro|25 min|timer/.test(msg))
    return { reply: "⏱️ **The Pomodoro Technique**\n\n1. Choose one task\n2. Work for **25 minutes** — full focus\n3. Take a **5-minute** break\n4. After 4 rounds → **15-30 min** long break\n\nThis technique is scientifically proven to improve focus and reduce mental fatigue. Try it now with your most important task!" };

  // Study
  if (/study|learn|exam|revision|memorize/.test(msg))
    return { reply: "📚 **Study Tips for Better Learning:**\n\n- 🔁 **Spaced Repetition** — Review at increasing intervals\n- ✍️ **Active Recall** — Test yourself, don't just re-read\n- 📝 **Feynman Technique** — Explain it simply like teaching a child\n- 😴 **Sleep** — Brain consolidates memory during sleep\n- 📵 **Phone-free** — Even visible phone reduces focus by 20%\n\nGood luck! 🌟" };

  // Who are you
  if (/who are you|your name|what are you/.test(msg))
    return { reply: "I'm **ARIA** — Adaptive Response Intelligence Assistant! 🌟\n\nI run on a **Node.js + Express** backend with data stored in JSON files. No external AI API needed!\n\nMy brain is built with smart pattern matching that handles hundreds of questions about productivity, planning, tasks, and more." };

  // Backend info
  if (/backend|server|node|express|how.*built|tech/.test(msg))
    return { reply: "🖥️ **ARIA's Tech Stack:**\n\n**Backend**\n- Runtime: **Node.js**\n- Framework: **Express.js**\n- Data storage: **JSON files**\n- Port: **3000**\n\n**Frontend**\n- Pure **HTML + CSS + JavaScript**\n- Talks to backend via **fetch API**\n- No frameworks needed!\n\n**Features**\n- REST API for tasks & reminders\n- Built-in AI brain (no external API)\n- Real-time data persistence" };

  // Default
  const fallbacks = [
    "That's interesting! I'm best at **productivity, planning, and task management**.\n\nTry asking:\n- *\"Give me productivity tips\"*\n- *\"Help me plan my day\"*\n- *\"Show my tasks\"*\n- *\"Tell me a joke\"*",
    "I'm still learning new things! 😊 Try asking about **productivity, tasks, planning, or motivation** — those are my specialties!",
    "Great question! For now I specialize in **personal productivity**. Ask me: *\"What can you do?\"* to see everything I can help with! 🌟",
  ];
  return { reply: fallbacks[Math.floor(Math.random() * fallbacks.length)] };
}

// ══════════════════════════════════════════════════════════════
//  API ROUTES
// ══════════════════════════════════════════════════════════════

// ── Health Check ────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'ARIA backend is running!', time: new Date().toISOString() });
});

// ── Chat ────────────────────────────────────────────────────
app.post('/api/chat', (req, res) => {
  const { message } = req.body;
  if (!message) return res.status(400).json({ error: 'Message is required' });

  // Log activity
  const activity = readJSON(ACTIVITY_FILE);
  activity.unshift({ icon: '💬', text: `Asked: "${message.slice(0, 40)}"`, time: new Date().toISOString() });
  if (activity.length > 50) activity.pop();
  writeJSON(ACTIVITY_FILE, activity);

  const response = ariaRespond(message);
  res.json(response);
});

// ── Tasks ────────────────────────────────────────────────────
app.get('/api/tasks', (req, res) => {
  res.json(readJSON(TASKS_FILE));
});

app.post('/api/tasks', (req, res) => {
  const { title, priority = 'medium', category = 'General' } = req.body;
  if (!title) return res.status(400).json({ error: 'Title is required' });

  const tasks = readJSON(TASKS_FILE);
  const task  = { id: Date.now(), title, priority, category, done: false, created: Date.now() };
  tasks.unshift(task);
  writeJSON(TASKS_FILE, tasks);

  const activity = readJSON(ACTIVITY_FILE);
  activity.unshift({ icon: '✅', text: `Added task: "${title}"`, time: new Date().toISOString() });
  writeJSON(ACTIVITY_FILE, activity);

  res.status(201).json(task);
});

app.patch('/api/tasks/:id/toggle', (req, res) => {
  const tasks = readJSON(TASKS_FILE);
  const task  = tasks.find(t => t.id === Number(req.params.id));
  if (!task) return res.status(404).json({ error: 'Task not found' });

  task.done = !task.done;
  writeJSON(TASKS_FILE, tasks);

  const activity = readJSON(ACTIVITY_FILE);
  activity.unshift({ icon: task.done ? '✓' : '↺', text: `${task.done ? 'Completed' : 'Reopened'}: "${task.title}"`, time: new Date().toISOString() });
  writeJSON(ACTIVITY_FILE, activity);

  res.json(task);
});

app.delete('/api/tasks/:id', (req, res) => {
  let tasks = readJSON(TASKS_FILE);
  const task = tasks.find(t => t.id === Number(req.params.id));
  if (!task) return res.status(404).json({ error: 'Task not found' });

  tasks = tasks.filter(t => t.id !== Number(req.params.id));
  writeJSON(TASKS_FILE, tasks);

  const activity = readJSON(ACTIVITY_FILE);
  activity.unshift({ icon: '🗑', text: `Deleted: "${task.title}"`, time: new Date().toISOString() });
  writeJSON(ACTIVITY_FILE, activity);

  res.json({ message: 'Task deleted' });
});

// ── Reminders ────────────────────────────────────────────────
app.get('/api/reminders', (req, res) => {
  res.json(readJSON(REMINDERS_FILE));
});

app.post('/api/reminders', (req, res) => {
  const { text, time } = req.body;
  if (!text || !time) return res.status(400).json({ error: 'text and time are required' });

  const reminders = readJSON(REMINDERS_FILE);
  const colors    = ['#e8604c', '#e9a825', '#2a9d8f', '#9b6dff'];
  const reminder  = { id: Date.now(), text, time, color: colors[reminders.length % colors.length] };
  reminders.push(reminder);
  writeJSON(REMINDERS_FILE, reminders);
  res.status(201).json(reminder);
});

app.delete('/api/reminders/:id', (req, res) => {
  let reminders = readJSON(REMINDERS_FILE);
  reminders = reminders.filter(r => r.id !== Number(req.params.id));
  writeJSON(REMINDERS_FILE, reminders);
  res.json({ message: 'Reminder deleted' });
});

// ── Activity ─────────────────────────────────────────────────
app.get('/api/activity', (req, res) => {
  res.json(readJSON(ACTIVITY_FILE).slice(0, 20));
});

// ── Dashboard Stats ──────────────────────────────────────────
app.get('/api/stats', (req, res) => {
  const tasks = readJSON(TASKS_FILE);
  res.json({
    total:   tasks.length,
    done:    tasks.filter(t => t.done).length,
    pending: tasks.filter(t => !t.done).length,
    high:    tasks.filter(t => t.priority === 'high' && !t.done).length,
  });
});

// ── Serve frontend for all other routes ──────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// ── Start Server ─────────────────────────────────────────────
app.listen(PORT, () => {
  console.log('\n╔════════════════════════════════════╗');
  console.log('║   ARIA Backend — Node.js + Express ║');
  console.log('╚════════════════════════════════════╝');
  console.log(`\n✅ Server running at: http://localhost:${PORT}`);
  console.log(`📡 API available at:  http://localhost:${PORT}/api`);
  console.log(`🌐 Frontend at:       http://localhost:${PORT}`);
  console.log('\nPress Ctrl+C to stop.\n');
});
